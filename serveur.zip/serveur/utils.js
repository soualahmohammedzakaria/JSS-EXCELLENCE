const QRCode = require('qrcode'); 

// On génére un code QR à partir de données JSON
async function generateQRCode(data) {
    try {
        const qrCodeData = JSON.stringify(data);
        const qrCodeImageUrl = await QRCode.toDataURL(qrCodeData);
        return qrCodeImageUrl;
    } catch (error) {
        console.error('Erreur lors de la génération du code QR :', error);
        throw error;
    }
}

/*const getQRCode = (Id, isCoach) => {
    // On détermine le préfixe en fonction du type d'utilisateur (coach ou adhérent)
    const prefix = isCoach ? 'C' : 'A';
    const qrCode = `${prefix}${userId}`;

    
  };*/
  

module.exports = { 
    generateQRCode,
 };
